import { useState, useEffect } from 'react'
import { Button } from './ui/button'
import { Input } from './ui/input'
import { Label } from './ui/label'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select'
import { Checkbox } from './ui/checkbox'
import { Avatar, AvatarFallback } from './ui/avatar'
import { Separator } from './ui/separator'
import { Target, Users, MapPin } from 'lucide-react'

interface Player {
  id: string
  name: string
  avatar: string
  handicap: number
}

interface Hole {
  number: number
  par: number
  distance: number
}

interface Round {
  id: string
  holes: Hole[]
  players: Player[]
  courseName: string
  date: string
  scores: { [playerId: string]: { [holeNumber: number]: { strokes: number, club?: string } } }
  currentHole: number
  isComplete: boolean
}

interface NewRoundProps {
  onStartRound: (round: Round) => void
}

const DEFAULT_HOLES_9: Hole[] = [
  { number: 1, par: 4, distance: 320 },
  { number: 2, par: 3, distance: 140 },
  { number: 3, par: 5, distance: 410 },
  { number: 4, par: 4, distance: 290 },
  { number: 5, par: 3, distance: 160 },
  { number: 6, par: 4, distance: 350 },
  { number: 7, par: 5, distance: 460 },
  { number: 8, par: 3, distance: 150 },
  { number: 9, par: 4, distance: 310 },
]

const DEFAULT_HOLES_18: Hole[] = [
  ...DEFAULT_HOLES_9,
  { number: 10, par: 4, distance: 300 },
  { number: 11, par: 3, distance: 130 },
  { number: 12, par: 5, distance: 440 },
  { number: 13, par: 4, distance: 330 },
  { number: 14, par: 3, distance: 150 },
  { number: 15, par: 4, distance: 370 },
  { number: 16, par: 5, distance: 480 },
  { number: 17, par: 3, distance: 165 },
  { number: 18, par: 4, distance: 340 },
]

export function NewRound({ onStartRound }: NewRoundProps) {
  const [players, setPlayers] = useState<Player[]>([])
  const [selectedPlayers, setSelectedPlayers] = useState<string[]>([])
  const [holes, setHoles] = useState<number>(18)
  const [courseName, setCourseName] = useState('')
  const [customHoles, setCustomHoles] = useState<Hole[]>([])
  const [useCustomHoles, setUseCustomHoles] = useState(false)

  useEffect(() => {
    const saved = localStorage.getItem('golfDuel_players')
    if (saved) {
      setPlayers(JSON.parse(saved))
    }
  }, [])

  useEffect(() => {
    if (useCustomHoles) {
      const defaultHoles = holes === 9 ? DEFAULT_HOLES_9 : DEFAULT_HOLES_18
      setCustomHoles(defaultHoles)
    }
  }, [holes, useCustomHoles])

  const handlePlayerToggle = (playerId: string) => {
    setSelectedPlayers(prev => 
      prev.includes(playerId) 
        ? prev.filter(id => id !== playerId)
        : [...prev, playerId]
    )
  }

  const handleHoleChange = (holeNumber: number, field: 'par' | 'distance', value: number) => {
    setCustomHoles(prev => 
      prev.map(hole => 
        hole.number === holeNumber 
          ? { ...hole, [field]: value }
          : hole
      )
    )
  }

  const handleStartRound = () => {
    if (selectedPlayers.length === 0) {
      alert('Please select at least one player')
      return
    }

    const selectedPlayerObjects = players.filter(p => selectedPlayers.includes(p.id))
    const holeConfig = useCustomHoles ? customHoles : (holes === 9 ? DEFAULT_HOLES_9 : DEFAULT_HOLES_18)
    
    const round: Round = {
      id: Date.now().toString(),
      holes: holeConfig,
      players: selectedPlayerObjects,
      courseName: courseName || 'Golf Course',
      date: new Date().toISOString(),
      scores: {},
      currentHole: 1,
      isComplete: false
    }

    // Initialize scores
    selectedPlayerObjects.forEach(player => {
      round.scores[player.id] = {}
      holeConfig.forEach(hole => {
        round.scores[player.id][hole.number] = { strokes: 0 }
      })
    })

    onStartRound(round)
  }

  const totalPar = useCustomHoles ? customHoles.reduce((sum, hole) => sum + hole.par, 0) : 
    (holes === 9 ? DEFAULT_HOLES_9 : DEFAULT_HOLES_18).reduce((sum, hole) => sum + hole.par, 0)

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <h1>Start New Round</h1>
          <p className="text-muted-foreground">Configure your round and select players</p>
        </div>

        <div className="space-y-6">
          {/* Course Setup */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="size-5" />
                Course Setup
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="courseName">Course Name (Optional)</Label>
                <Input
                  id="courseName"
                  value={courseName}
                  onChange={(e) => setCourseName(e.target.value)}
                  placeholder="e.g., Pine Valley Golf Club"
                />
              </div>
              
              <div>
                <Label>Number of Holes</Label>
                <Select value={holes.toString()} onValueChange={(value) => setHoles(parseInt(value))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="9">9 Holes</SelectItem>
                    <SelectItem value="18">18 Holes</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="customHoles"
                  checked={useCustomHoles}
                  onCheckedChange={setUseCustomHoles}
                />
                <Label htmlFor="customHoles">Customize hole details</Label>
              </div>
            </CardContent>
          </Card>

          {/* Player Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="size-5" />
                Select Players
              </CardTitle>
            </CardHeader>
            <CardContent>
              {players.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">
                  No players available. Add players first in the Players section.
                </p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {players.map((player) => (
                    <div key={player.id} className="flex items-center space-x-3 p-3 rounded-lg border">
                      <Checkbox
                        id={player.id}
                        checked={selectedPlayers.includes(player.id)}
                        onCheckedChange={() => handlePlayerToggle(player.id)}
                      />
                      <Avatar className="size-8">
                        <AvatarFallback>{player.avatar}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-medium">{player.name}</p>
                        <p className="text-sm text-muted-foreground">Handicap: {player.handicap}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Custom Holes Configuration */}
          {useCustomHoles && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="size-5" />
                  Hole Configuration
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {customHoles.map((hole) => (
                    <div key={hole.number} className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-3">Hole {hole.number}</h4>
                      <div className="space-y-2">
                        <div>
                          <Label>Par</Label>
                          <Input
                            type="number"
                            value={hole.par}
                            onChange={(e) => handleHoleChange(hole.number, 'par', parseInt(e.target.value) || 3)}
                            min="3"
                            max="6"
                          />
                        </div>
                        <div>
                          <Label>Distance (meters)</Label>
                          <Input
                            type="number"
                            value={hole.distance}
                            onChange={(e) => handleHoleChange(hole.number, 'distance', parseInt(e.target.value) || 0)}
                            min="0"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <Separator className="my-4" />
                
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">
                    Total Par: <span className="font-medium">{totalPar}</span>
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Start Round */}
          <Card>
            <CardContent className="pt-6">
              <div className="text-center space-y-4">
                <div className="text-sm text-muted-foreground">
                  <p>{holes} holes • Par {totalPar}</p>
                  <p>{selectedPlayers.length} player{selectedPlayers.length !== 1 ? 's' : ''} selected</p>
                </div>
                
                <Button 
                  onClick={handleStartRound} 
                  size="lg"
                  disabled={selectedPlayers.length === 0}
                  className="w-full md:w-auto"
                >
                  <Target className="size-4 mr-2" />
                  Start Round
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}