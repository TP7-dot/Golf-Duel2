import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { Avatar, AvatarFallback } from './ui/avatar'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table'
import { History, Calendar, MapPin, Users, Download, Trophy } from 'lucide-react'
import { Separator } from './ui/separator'

interface Player {
  id: string
  name: string
  avatar: string
  handicap: number
}

interface Round {
  id: string
  holes: { number: number; par: number; distance: number }[]
  players: Player[]
  courseName: string
  date: string
  scores: { [playerId: string]: { [holeNumber: number]: { strokes: number, club?: string } } }
  isComplete: boolean
}

export function RoundHistory() {
  const [rounds, setRounds] = useState<Round[]>([])
  const [selectedRound, setSelectedRound] = useState<Round | null>(null)

  useEffect(() => {
    const saved = localStorage.getItem('golfDuel_rounds')
    if (saved) {
      const allRounds = JSON.parse(saved)
      setRounds(allRounds.filter((r: Round) => r.isComplete).sort((a: Round, b: Round) => 
        new Date(b.date).getTime() - new Date(a.date).getTime()
      ))
    }
  }, [])

  const getPlayerTotalScore = (round: Round, playerId: string) => {
    return round.holes.reduce((sum, hole) => {
      return sum + (round.scores[playerId]?.[hole.number]?.strokes || 0)
    }, 0)
  }

  const getTotalPar = (round: Round) => {
    return round.holes.reduce((sum, hole) => sum + hole.par, 0)
  }

  const getScoreRelativeToPar = (strokes: number, par: number) => {
    const diff = strokes - par
    if (diff <= -2) return { name: 'Eagle', color: 'bg-yellow-100 text-yellow-800' }
    if (diff === -1) return { name: 'Birdie', color: 'bg-green-100 text-green-800' }
    if (diff === 0) return { name: 'Par', color: 'bg-blue-100 text-blue-800' }
    if (diff === 1) return { name: 'Bogey', color: 'bg-orange-100 text-orange-800' }
    if (diff === 2) return { name: 'Double Bogey', color: 'bg-red-100 text-red-800' }
    return { name: `+${diff}`, color: 'bg-red-100 text-red-800' }
  }

  const exportToCSV = (round: Round) => {
    const csvContent = [
      // Header
      ['Hole', 'Par', 'Distance', ...round.players.map(p => p.name)].join(','),
      // Data rows
      ...round.holes.map(hole => [
        hole.number,
        hole.par,
        hole.distance,
        ...round.players.map(player => round.scores[player.id]?.[hole.number]?.strokes || 0)
      ].join(',')),
      // Totals
      ['TOTAL', getTotalPar(round), '', ...round.players.map(player => getPlayerTotalScore(round, player.id))].join(','),
      ['VS PAR', '', '', ...round.players.map(player => {
        const total = getPlayerTotalScore(round, player.id)
        const par = getTotalPar(round)
        const diff = total - par
        return diff > 0 ? `+${diff}` : diff.toString()
      })].join(',')
    ].join('\n')

    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `golf-round-${round.courseName}-${new Date(round.date).toLocaleDateString()}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  const getRoundWinner = (round: Round) => {
    if (round.players.length === 0) return null
    
    const playerScores = round.players.map(player => ({
      player,
      score: getPlayerTotalScore(round, player.id)
    }))
    
    playerScores.sort((a, b) => a.score - b.score)
    return playerScores[0]
  }

  return (
    <div className="p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-6">
          <h1>Round History</h1>
          <p className="text-muted-foreground">View and export your completed golf rounds</p>
        </div>

        {rounds.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <History className="size-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground mb-4">No completed rounds yet</p>
              <p className="text-sm text-muted-foreground">
                Complete some rounds to see your golf history here
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {rounds.map((round) => {
              const winner = getRoundWinner(round)
              const totalPar = getTotalPar(round)
              
              return (
                <Card key={round.id}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center gap-4">
                          <h3 className="font-semibold">{round.courseName}</h3>
                          {winner && (
                            <Badge className="bg-yellow-100 text-yellow-800">
                              <Trophy className="size-3 mr-1" />
                              Winner: {winner.player.name}
                            </Badge>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="size-4" />
                            {new Date(round.date).toLocaleDateString()}
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="size-4" />
                            {round.holes.length} holes • Par {totalPar}
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="size-4" />
                            {round.players.length} player{round.players.length !== 1 ? 's' : ''}
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          {round.players.map((player) => (
                            <div key={player.id} className="flex items-center gap-1">
                              <Avatar className="size-6">
                                <AvatarFallback className="text-xs">{player.avatar}</AvatarFallback>
                              </Avatar>
                              <span className="text-sm">
                                {player.name}: {getPlayerTotalScore(round, player.id)}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => exportToCSV(round)}>
                          <Download className="size-4 mr-1" />
                          Export
                        </Button>
                        
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button size="sm" onClick={() => setSelectedRound(round)}>
                              View Scorecard
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                            <DialogHeader>
                              <DialogTitle>{round.courseName} - Scorecard</DialogTitle>
                              <p className="text-sm text-muted-foreground">
                                {new Date(round.date).toLocaleDateString()} • {round.holes.length} holes
                              </p>
                            </DialogHeader>
                            
                            {selectedRound && selectedRound.id === round.id && (
                              <div className="space-y-4">
                                {/* Scorecard Table */}
                                <div className="border rounded-lg overflow-hidden">
                                  <Table>
                                    <TableHeader>
                                      <TableRow>
                                        <TableHead className="w-16">Hole</TableHead>
                                        <TableHead className="w-16">Par</TableHead>
                                        <TableHead className="w-20">Distance</TableHead>
                                        {round.players.map((player) => (
                                          <TableHead key={player.id} className="text-center">
                                            <div className="flex items-center justify-center gap-1">
                                              <span>{player.avatar}</span>
                                              <span>{player.name}</span>
                                            </div>
                                          </TableHead>
                                        ))}
                                      </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                      {round.holes.map((hole) => (
                                        <TableRow key={hole.number}>
                                          <TableCell className="font-medium">{hole.number}</TableCell>
                                          <TableCell>{hole.par}</TableCell>
                                          <TableCell>{hole.distance}</TableCell>
                                          {round.players.map((player) => {
                                            const strokes = round.scores[player.id]?.[hole.number]?.strokes || 0
                                            const scoreInfo = getScoreRelativeToPar(strokes, hole.par)
                                            return (
                                              <TableCell key={player.id} className="text-center">
                                                <div className="space-y-1">
                                                  <div className="font-medium">{strokes}</div>
                                                  {strokes > 0 && (
                                                    <Badge variant="secondary" className={`text-xs ${scoreInfo.color}`}>
                                                      {scoreInfo.name}
                                                    </Badge>
                                                  )}
                                                </div>
                                              </TableCell>
                                            )
                                          })}
                                        </TableRow>
                                      ))}
                                      
                                      {/* Front/Back 9 Subtotals for 18 hole rounds */}
                                      {round.holes.length === 18 && (
                                        <>
                                          <TableRow className="bg-muted/50">
                                            <TableCell className="font-medium">OUT</TableCell>
                                            <TableCell>
                                              {round.holes.slice(0, 9).reduce((sum, h) => sum + h.par, 0)}
                                            </TableCell>
                                            <TableCell>-</TableCell>
                                            {round.players.map((player) => (
                                              <TableCell key={player.id} className="text-center font-medium">
                                                {round.holes.slice(0, 9).reduce((sum, hole) => 
                                                  sum + (round.scores[player.id]?.[hole.number]?.strokes || 0), 0
                                                )}
                                              </TableCell>
                                            ))}
                                          </TableRow>
                                          <TableRow className="bg-muted/50">
                                            <TableCell className="font-medium">IN</TableCell>
                                            <TableCell>
                                              {round.holes.slice(9).reduce((sum, h) => sum + h.par, 0)}
                                            </TableCell>
                                            <TableCell>-</TableCell>
                                            {round.players.map((player) => (
                                              <TableCell key={player.id} className="text-center font-medium">
                                                {round.holes.slice(9).reduce((sum, hole) => 
                                                  sum + (round.scores[player.id]?.[hole.number]?.strokes || 0), 0
                                                )}
                                              </TableCell>
                                            ))}
                                          </TableRow>
                                        </>
                                      )}
                                      
                                      {/* Totals */}
                                      <TableRow className="bg-primary/5 font-bold">
                                        <TableCell>TOTAL</TableCell>
                                        <TableCell>{totalPar}</TableCell>
                                        <TableCell>-</TableCell>
                                        {round.players.map((player) => {
                                          const total = getPlayerTotalScore(round, player.id)
                                          const vsPar = total - totalPar
                                          return (
                                            <TableCell key={player.id} className="text-center">
                                              <div className="space-y-1">
                                                <div>{total}</div>
                                                <div className={`text-sm ${
                                                  vsPar > 0 ? 'text-red-600' : 
                                                  vsPar < 0 ? 'text-green-600' : 'text-blue-600'
                                                }`}>
                                                  {vsPar > 0 ? '+' : ''}{vsPar}
                                                </div>
                                              </div>
                                            </TableCell>
                                          )
                                        })}
                                      </TableRow>
                                    </TableBody>
                                  </Table>
                                </div>
                                
                                <div className="flex justify-end">
                                  <Button onClick={() => exportToCSV(round)}>
                                    <Download className="size-4 mr-2" />
                                    Export Scorecard
                                  </Button>
                                </div>
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}