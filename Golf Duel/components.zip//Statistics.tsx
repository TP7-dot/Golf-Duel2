import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select'
import { Avatar, AvatarFallback } from './ui/avatar'
import { Badge } from './ui/badge'
import { BarChart3, TrendingUp, Target, Trophy } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts'

interface Player {
  id: string
  name: string
  avatar: string
  handicap: number
}

interface Round {
  id: string
  holes: { number: number; par: number; distance: number }[]
  players: Player[]
  courseName: string
  date: string
  scores: { [playerId: string]: { [holeNumber: number]: { strokes: number, club?: string } } }
  isComplete: boolean
}

export function Statistics() {
  const [players, setPlayers] = useState<Player[]>([])
  const [rounds, setRounds] = useState<Round[]>([])
  const [selectedPlayer, setSelectedPlayer] = useState<string>('')

  useEffect(() => {
    const savedPlayers = localStorage.getItem('golfDuel_players')
    const savedRounds = localStorage.getItem('golfDuel_rounds')
    
    if (savedPlayers) {
      const playersData = JSON.parse(savedPlayers)
      setPlayers(playersData)
      if (playersData.length > 0 && !selectedPlayer) {
        setSelectedPlayer(playersData[0].id)
      }
    }
    
    if (savedRounds) {
      setRounds(JSON.parse(savedRounds).filter((r: Round) => r.isComplete))
    }
  }, [])

  const getPlayerRounds = (playerId: string) => {
    return rounds.filter(round => round.players.some(p => p.id === playerId))
  }

  const getPlayerStats = (playerId: string) => {
    const playerRounds = getPlayerRounds(playerId)
    
    if (playerRounds.length === 0) {
      return {
        totalRounds: 0,
        averageScore: 0,
        bestScore: null,
        worstScore: null,
        averageVsPar: 0,
        birdiesOrBetter: 0,
        pars: 0,
        bogeys: 0,
        doubleBogeyOrWorse: 0
      }
    }

    let totalStrokes = 0
    let totalPar = 0
    let birdiesOrBetter = 0
    let pars = 0
    let bogeys = 0
    let doubleBogeyOrWorse = 0
    let bestScore = Infinity
    let worstScore = 0

    playerRounds.forEach(round => {
      let roundScore = 0
      let roundPar = 0
      
      round.holes.forEach(hole => {
        const holeScore = round.scores[playerId]?.[hole.number]?.strokes || 0
        roundScore += holeScore
        roundPar += hole.par
        
        const diff = holeScore - hole.par
        if (diff <= -1) birdiesOrBetter++
        else if (diff === 0) pars++
        else if (diff === 1) bogeys++
        else if (diff >= 2) doubleBogeyOrWorse++
      })
      
      totalStrokes += roundScore
      totalPar += roundPar
      bestScore = Math.min(bestScore, roundScore)
      worstScore = Math.max(worstScore, roundScore)
    })

    return {
      totalRounds: playerRounds.length,
      averageScore: totalStrokes / playerRounds.length,
      bestScore: bestScore === Infinity ? null : bestScore,
      worstScore,
      averageVsPar: (totalStrokes - totalPar) / playerRounds.length,
      birdiesOrBetter,
      pars,
      bogeys,
      doubleBogeyOrWorse
    }
  }

  const getScoreProgressData = (playerId: string) => {
    const playerRounds = getPlayerRounds(playerId)
    return playerRounds.map((round, index) => {
      const totalStrokes = round.holes.reduce((sum, hole) => {
        return sum + (round.scores[playerId]?.[hole.number]?.strokes || 0)
      }, 0)
      const totalPar = round.holes.reduce((sum, hole) => sum + hole.par, 0)
      
      return {
        round: index + 1,
        score: totalStrokes,
        par: totalPar,
        vsPar: totalStrokes - totalPar,
        date: new Date(round.date).toLocaleDateString()
      }
    })
  }

  const getHolePerformanceData = (playerId: string) => {
    const holeStats: { [holeNumber: number]: { strokes: number[], par: number } } = {}
    
    getPlayerRounds(playerId).forEach(round => {
      round.holes.forEach(hole => {
        if (!holeStats[hole.number]) {
          holeStats[hole.number] = { strokes: [], par: hole.par }
        }
        const strokes = round.scores[playerId]?.[hole.number]?.strokes || 0
        if (strokes > 0) {
          holeStats[hole.number].strokes.push(strokes)
        }
      })
    })

    return Object.keys(holeStats).map(holeNum => {
      const hole = parseInt(holeNum)
      const strokes = holeStats[hole].strokes
      const avgStrokes = strokes.length > 0 ? strokes.reduce((a, b) => a + b, 0) / strokes.length : 0
      
      return {
        hole: hole,
        average: Number(avgStrokes.toFixed(1)),
        par: holeStats[hole].par,
        vsPar: Number((avgStrokes - holeStats[hole].par).toFixed(1))
      }
    }).sort((a, b) => a.hole - b.hole)
  }

  const selectedPlayerData = selectedPlayer ? players.find(p => p.id === selectedPlayer) : null
  const stats = selectedPlayer ? getPlayerStats(selectedPlayer) : null
  const progressData = selectedPlayer ? getScoreProgressData(selectedPlayer) : []
  const holeData = selectedPlayer ? getHolePerformanceData(selectedPlayer) : []

  return (
    <div className="p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1>Statistics & Analytics</h1>
            <p className="text-muted-foreground">Track your performance and improvement over time</p>
          </div>
          
          {players.length > 0 && (
            <Select value={selectedPlayer} onValueChange={setSelectedPlayer}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Select player" />
              </SelectTrigger>
              <SelectContent>
                {players.map((player) => (
                  <SelectItem key={player.id} value={player.id}>
                    <div className="flex items-center gap-2">
                      <span>{player.avatar}</span>
                      {player.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {!selectedPlayerData || rounds.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <BarChart3 className="size-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground mb-4">
                {players.length === 0 ? 'No players found' : 'No completed rounds found'}
              </p>
              <p className="text-sm text-muted-foreground">
                {players.length === 0 ? 'Add players first to see statistics' : 'Complete some rounds to see your performance statistics'}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {/* Player Overview */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback>{selectedPlayerData.avatar}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3>{selectedPlayerData.name}</h3>
                    <Badge variant="secondary">Handicap: {selectedPlayerData.handicap}</Badge>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{stats?.totalRounds || 0}</div>
                    <div className="text-sm text-muted-foreground">Rounds Played</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">
                      {stats?.averageScore ? stats.averageScore.toFixed(1) : 'N/A'}
                    </div>
                    <div className="text-sm text-muted-foreground">Average Score</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{stats?.bestScore || 'N/A'}</div>
                    <div className="text-sm text-muted-foreground">Best Score</div>
                  </div>
                  <div className="text-center">
                    <div className={`text-2xl font-bold ${
                      (stats?.averageVsPar || 0) > 0 ? 'text-red-600' : 
                      (stats?.averageVsPar || 0) < 0 ? 'text-green-600' : 'text-blue-600'
                    }`}>
                      {stats?.averageVsPar ? 
                        (stats.averageVsPar > 0 ? '+' : '') + stats.averageVsPar.toFixed(1) : 'N/A'}
                    </div>
                    <div className="text-sm text-muted-foreground">Avg vs Par</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Score Progress Chart */}
            {progressData.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="size-5" />
                    Score Progress
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={progressData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="round" />
                      <YAxis />
                      <Tooltip 
                        labelFormatter={(value) => `Round ${value}`}
                        formatter={(value, name) => [
                          value,
                          name === 'score' ? 'Score' : name === 'par' ? 'Par' : 'vs Par'
                        ]}
                      />
                      <Line type="monotone" dataKey="score" stroke="#8884d8" strokeWidth={2} />
                      <Line type="monotone" dataKey="par" stroke="#82ca9d" strokeDasharray="5 5" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}

            {/* Hole Performance */}
            {holeData.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="size-5" />
                    Hole-by-Hole Performance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={holeData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="hole" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value, name) => [
                          value,
                          name === 'average' ? 'Avg Strokes' : name === 'par' ? 'Par' : 'vs Par'
                        ]}
                      />
                      <Bar dataKey="average" fill="#8884d8" />
                      <Bar dataKey="par" fill="#82ca9d" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}

            {/* Score Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="size-5" />
                  Score Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 border rounded-lg">
                    <div className="text-2xl font-bold text-yellow-600">{stats?.birdiesOrBetter || 0}</div>
                    <div className="text-sm text-muted-foreground">Eagles & Birdies</div>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{stats?.pars || 0}</div>
                    <div className="text-sm text-muted-foreground">Pars</div>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">{stats?.bogeys || 0}</div>
                    <div className="text-sm text-muted-foreground">Bogeys</div>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <div className="text-2xl font-bold text-red-600">{stats?.doubleBogeyOrWorse || 0}</div>
                    <div className="text-sm text-muted-foreground">Double Bogey+</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}