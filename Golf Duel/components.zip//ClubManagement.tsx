import { useState, useEffect } from 'react'
import { Button } from './ui/button'
import { Input } from './ui/input'
import { Label } from './ui/label'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select'
import { Plus, Edit, Trash2, Target } from 'lucide-react'
import { Badge } from './ui/badge'

interface Club {
  id: string
  name: string
  type: string
  distance: number
  uses: number
}

const CLUB_TYPES = [
  'Driver',
  'Fairway Wood',
  '3 Wood',
  '5 Wood',
  'Hybrid',
  '3 Iron',
  '4 Iron',
  '5 Iron',
  '6 Iron',
  '7 Iron',
  '8 Iron',
  '9 Iron',
  'Pitching Wedge',
  'Sand Wedge',
  'Lob Wedge',
  'Putter'
]

export function ClubManagement() {
  const [clubs, setClubs] = useState<Club[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingClub, setEditingClub] = useState<Club | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    type: '',
    distance: 0
  })

  useEffect(() => {
    const saved = localStorage.getItem('golfDuel_clubs')
    if (saved) {
      setClubs(JSON.parse(saved))
    } else {
      // Add default clubs for new users
      const defaultClubs: Club[] = [
        { id: '1', name: 'Driver', type: 'Driver', distance: 230, uses: 0 },
        { id: '2', name: '7 Iron', type: '7 Iron', distance: 140, uses: 0 },
        { id: '3', name: 'Pitching Wedge', type: 'Pitching Wedge', distance: 90, uses: 0 },
        { id: '4', name: 'Putter', type: 'Putter', distance: 0, uses: 0 }
      ]
      setClubs(defaultClubs)
      localStorage.setItem('golfDuel_clubs', JSON.stringify(defaultClubs))
    }
  }, [])

  const saveToStorage = (newClubs: Club[]) => {
    localStorage.setItem('golfDuel_clubs', JSON.stringify(newClubs))
    setClubs(newClubs)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (editingClub) {
      const updated = clubs.map(c => 
        c.id === editingClub.id 
          ? { ...c, ...formData }
          : c
      )
      saveToStorage(updated)
    } else {
      const newClub: Club = {
        id: Date.now().toString(),
        ...formData,
        uses: 0
      }
      saveToStorage([...clubs, newClub])
    }
    
    setFormData({ name: '', type: '', distance: 0 })
    setEditingClub(null)
    setIsDialogOpen(false)
  }

  const handleEdit = (club: Club) => {
    setEditingClub(club)
    setFormData({
      name: club.name,
      type: club.type,
      distance: club.distance
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    const updated = clubs.filter(c => c.id !== id)
    saveToStorage(updated)
  }

  const resetDialog = () => {
    setFormData({ name: '', type: '', distance: 0 })
    setEditingClub(null)
    setIsDialogOpen(false)
  }

  const getClubTypeColor = (type: string) => {
    if (type === 'Driver') return 'bg-red-100 text-red-800'
    if (type === 'Putter') return 'bg-green-100 text-green-800'
    if (type.includes('Wood') || type === 'Hybrid') return 'bg-blue-100 text-blue-800'
    if (type.includes('Iron')) return 'bg-purple-100 text-purple-800'
    if (type.includes('Wedge')) return 'bg-orange-100 text-orange-800'
    return 'bg-gray-100 text-gray-800'
  }

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1>Club Management</h1>
            <p className="text-muted-foreground">Manage your golf clubs and their distances</p>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => resetDialog()}>
                <Plus className="size-4 mr-2" />
                Add Club
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{editingClub ? 'Edit Club' : 'Add New Club'}</DialogTitle>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="name">Club Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., TaylorMade Driver"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="type">Club Type</Label>
                  <Select 
                    value={formData.type} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, type: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select club type" />
                    </SelectTrigger>
                    <SelectContent>
                      {CLUB_TYPES.map((type) => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="distance">Average Distance (meters)</Label>
                  <Input
                    id="distance"
                    type="number"
                    value={formData.distance}
                    onChange={(e) => setFormData(prev => ({ ...prev, distance: parseInt(e.target.value) || 0 }))}
                    placeholder="0"
                  />
                </div>
                
                <div className="flex gap-2 pt-4">
                  <Button type="submit" className="flex-1">
                    {editingClub ? 'Update Club' : 'Add Club'}
                  </Button>
                  <Button type="button" variant="outline" onClick={resetDialog}>
                    Cancel
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {clubs.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Target className="size-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground mb-4">No clubs added yet</p>
              <Button onClick={() => setIsDialogOpen(true)}>
                <Plus className="size-4 mr-2" />
                Add Your First Club
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {clubs.map((club) => (
              <Card key={club.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base">{club.name}</CardTitle>
                      <Badge className={getClubTypeColor(club.type)}>{club.type}</Badge>
                    </div>
                    <div className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => handleEdit(club)}>
                        <Edit className="size-4" />
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => handleDelete(club.id)}>
                        <Trash2 className="size-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Distance:</span>
                      <span>{club.distance > 0 ? `${club.distance}m` : 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Times Used:</span>
                      <span>{club.uses}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}