import { useState, useEffect } from 'react'
import { Button } from './ui/button'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Avatar, AvatarFallback } from './ui/avatar'
import { Badge } from './ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog'
import { Progress } from './ui/progress'
import { ChevronLeft, ChevronRight, Plus, Minus, Flag, Trophy, Target } from 'lucide-react'
import { Separator } from './ui/separator'

interface Player {
  id: string
  name: string
  avatar: string
  handicap: number
}

interface Hole {
  number: number
  par: number
  distance: number
}

interface Club {
  id: string
  name: string
  type: string
  distance: number
}

interface Round {
  id: string
  holes: Hole[]
  players: Player[]
  courseName: string
  date: string
  scores: { [playerId: string]: { [holeNumber: number]: { strokes: number, club?: string } } }
  currentHole: number
  isComplete: boolean
}

interface ActiveRoundProps {
  round: Round
  onFinishRound: () => void
  onUpdateRound: (round: Round) => void
}

export function ActiveRound({ round, onFinishRound, onUpdateRound }: ActiveRoundProps) {
  const [currentPlayerIndex, setCurrentPlayerIndex] = useState(0)
  const [clubs, setClubs] = useState<Club[]>([])
  const [showFinishDialog, setShowFinishDialog] = useState(false)

  useEffect(() => {
    const saved = localStorage.getItem('golfDuel_clubs')
    if (saved) {
      setClubs(JSON.parse(saved))
    }
  }, [])

  const currentHole = round.holes.find(h => h.number === round.currentHole)
  const currentPlayer = round.players[currentPlayerIndex]
  const totalHoles = round.holes.length

  const getScoreRelativeToPar = (strokes: number, par: number) => {
    const diff = strokes - par
    if (diff <= -2) return { name: 'Eagle', color: 'bg-yellow-100 text-yellow-800' }
    if (diff === -1) return { name: 'Birdie', color: 'bg-green-100 text-green-800' }
    if (diff === 0) return { name: 'Par', color: 'bg-blue-100 text-blue-800' }
    if (diff === 1) return { name: 'Bogey', color: 'bg-orange-100 text-orange-800' }
    if (diff === 2) return { name: 'Double Bogey', color: 'bg-red-100 text-red-800' }
    return { name: `+${diff}`, color: 'bg-red-100 text-red-800' }
  }

  const updateScore = (playerId: string, holeNumber: number, strokes: number, club?: string) => {
    const updatedRound = {
      ...round,
      scores: {
        ...round.scores,
        [playerId]: {
          ...round.scores[playerId],
          [holeNumber]: { strokes, club }
        }
      }
    }
    onUpdateRound(updatedRound)
  }

  const addStroke = () => {
    const currentStrokes = round.scores[currentPlayer.id][round.currentHole].strokes
    updateScore(currentPlayer.id, round.currentHole, currentStrokes + 1)
  }

  const removeStroke = () => {
    const currentStrokes = round.scores[currentPlayer.id][round.currentHole].strokes
    if (currentStrokes > 0) {
      updateScore(currentPlayer.id, round.currentHole, currentStrokes - 1)
    }
  }

  const selectClub = (clubId: string) => {
    const currentStrokes = round.scores[currentPlayer.id][round.currentHole].strokes
    const club = clubs.find(c => c.id === clubId)
    updateScore(currentPlayer.id, round.currentHole, currentStrokes, club?.name)
  }

  const nextPlayer = () => {
    if (currentPlayerIndex < round.players.length - 1) {
      setCurrentPlayerIndex(currentPlayerIndex + 1)
    }
  }

  const prevPlayer = () => {
    if (currentPlayerIndex > 0) {
      setCurrentPlayerIndex(currentPlayerIndex - 1)
    }
  }

  const nextHole = () => {
    if (round.currentHole < totalHoles) {
      const updatedRound = {
        ...round,
        currentHole: round.currentHole + 1
      }
      onUpdateRound(updatedRound)
      setCurrentPlayerIndex(0)
    } else {
      setShowFinishDialog(true)
    }
  }

  const prevHole = () => {
    if (round.currentHole > 1) {
      const updatedRound = {
        ...round,
        currentHole: round.currentHole - 1
      }
      onUpdateRound(updatedRound)
      setCurrentPlayerIndex(0)
    }
  }

  const finishRound = () => {
    // Save completed round to history
    const completedRound = { ...round, isComplete: true }
    const savedRounds = JSON.parse(localStorage.getItem('golfDuel_rounds') || '[]')
    savedRounds.push(completedRound)
    localStorage.setItem('golfDuel_rounds', JSON.stringify(savedRounds))
    
    // Update player statistics
    const savedPlayers = JSON.parse(localStorage.getItem('golfDuel_players') || '[]')
    const updatedPlayers = savedPlayers.map((player: Player) => {
      const roundPlayer = round.players.find(p => p.id === player.id)
      if (roundPlayer) {
        const totalStrokes = round.holes.reduce((sum, hole) => 
          sum + round.scores[player.id][hole.number].strokes, 0
        )
        return {
          ...player,
          totalRounds: (player.totalRounds || 0) + 1,
          bestScore: !player.bestScore || totalStrokes < player.bestScore ? totalStrokes : player.bestScore
        }
      }
      return player
    })
    localStorage.setItem('golfDuel_players', JSON.stringify(updatedPlayers))
    
    onFinishRound()
  }

  const getPlayerTotalScore = (playerId: string) => {
    return round.holes.reduce((sum, hole) => {
      return sum + (round.scores[playerId][hole.number]?.strokes || 0)
    }, 0)
  }

  const getPlayerScoreVsPar = (playerId: string) => {
    const totalStrokes = getPlayerTotalScore(playerId)
    const totalPar = round.holes.reduce((sum, hole) => sum + hole.par, 0)
    return totalStrokes - totalPar
  }

  const progress = (round.currentHole / totalHoles) * 100

  if (!currentHole) return null

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <h1>{round.courseName}</h1>
            <Button variant="outline" onClick={() => setShowFinishDialog(true)}>
              <Trophy className="size-4 mr-2" />
              Finish Round
            </Button>
          </div>
          <Progress value={progress} className="mb-2" />
          <p className="text-sm text-muted-foreground">
            Hole {round.currentHole} of {totalHoles} • {Math.round(progress)}% Complete
          </p>
        </div>

        {/* Current Hole Info */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Flag className="size-5" />
                Hole {currentHole.number}
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={prevHole} disabled={round.currentHole === 1}>
                  <ChevronLeft className="size-4" />
                </Button>
                <Button size="sm" variant="outline" onClick={nextHole}>
                  {round.currentHole === totalHoles ? 'Finish' : <ChevronRight className="size-4" />}
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-6 text-sm">
              <div>
                <span className="text-muted-foreground">Par:</span>
                <span className="ml-1 font-medium">{currentHole.par}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Distance:</span>
                <span className="ml-1 font-medium">{currentHole.distance}m</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Player Scoring */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarFallback>{currentPlayer.avatar}</AvatarFallback>
                </Avatar>
                <div>
                  <p>{currentPlayer.name}</p>
                  <p className="text-sm text-muted-foreground">Handicap: {currentPlayer.handicap}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={prevPlayer} disabled={currentPlayerIndex === 0}>
                  <ChevronLeft className="size-4" />
                </Button>
                <Button size="sm" variant="outline" onClick={nextPlayer} disabled={currentPlayerIndex === round.players.length - 1}>
                  <ChevronRight className="size-4" />
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Stroke Counter */}
            <div className="text-center">
              <div className="flex items-center justify-center gap-4 mb-4">
                <Button size="lg" variant="outline" onClick={removeStroke}>
                  <Minus className="size-4" />
                </Button>
                <div className="text-3xl font-bold min-w-[60px]">
                  {round.scores[currentPlayer.id][round.currentHole].strokes}
                </div>
                <Button size="lg" onClick={addStroke}>
                  <Plus className="size-4" />
                </Button>
              </div>
              
              {round.scores[currentPlayer.id][round.currentHole].strokes > 0 && (
                <Badge className={getScoreRelativeToPar(
                  round.scores[currentPlayer.id][round.currentHole].strokes, 
                  currentHole.par
                ).color}>
                  {getScoreRelativeToPar(
                    round.scores[currentPlayer.id][round.currentHole].strokes, 
                    currentHole.par
                  ).name}
                </Badge>
              )}
            </div>

            {/* Club Selection */}
            {clubs.length > 0 && (
              <div>
                <label className="text-sm font-medium mb-2 block">Select Club</label>
                <Select 
                  value={round.scores[currentPlayer.id][round.currentHole].club || ''} 
                  onValueChange={selectClub}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose club used" />
                  </SelectTrigger>
                  <SelectContent>
                    {clubs.map((club) => (
                      <SelectItem key={club.id} value={club.id}>
                        {club.name} ({club.type}) - {club.distance}m
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Leaderboard */}
        <Card>
          <CardHeader>
            <CardTitle>Current Scores</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {round.players
                .sort((a, b) => getPlayerTotalScore(a.id) - getPlayerTotalScore(b.id))
                .map((player, index) => {
                  const totalStrokes = getPlayerTotalScore(player.id)
                  const scoreVsPar = getPlayerScoreVsPar(player.id)
                  return (
                    <div key={player.id} className="flex items-center justify-between p-3 rounded-lg border">
                      <div className="flex items-center gap-3">
                        <div className="text-lg font-bold text-muted-foreground">
                          {index + 1}
                        </div>
                        <Avatar className="size-8">
                          <AvatarFallback>{player.avatar}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{player.name}</p>
                          <p className="text-sm text-muted-foreground">
                            Hole {round.currentHole}: {round.scores[player.id][round.currentHole].strokes || 0}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">{totalStrokes}</p>
                        <p className={`text-sm ${scoreVsPar > 0 ? 'text-red-600' : scoreVsPar < 0 ? 'text-green-600' : 'text-blue-600'}`}>
                          {scoreVsPar > 0 ? '+' : ''}{scoreVsPar}
                        </p>
                      </div>
                    </div>
                  )
                })}
            </div>
          </CardContent>
        </Card>

        {/* Finish Round Dialog */}
        <Dialog open={showFinishDialog} onOpenChange={setShowFinishDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Finish Round?</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p>Are you sure you want to finish this round? Your scores will be saved to history.</p>
              <div className="flex gap-2">
                <Button onClick={finishRound} className="flex-1">
                  Yes, Finish Round
                </Button>
                <Button variant="outline" onClick={() => setShowFinishDialog(false)} className="flex-1">
                  Continue Playing
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}