import { useState, useEffect } from 'react'
import { Button } from './ui/button'
import { Input } from './ui/input'
import { Label } from './ui/label'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog'
import { Plus, Edit, Trash2 } from 'lucide-react'
import { Badge } from './ui/badge'

interface Player {
  id: string
  name: string
  avatar: string
  handicap: number
  totalRounds: number
  bestScore: number | null
}

const AVATAR_OPTIONS = [
  '👤', '🏌️‍♂️', '🏌️‍♀️', '⛳', '🎯', '🏆', '🥇', '🎪', '🎭', '🎨',
  '🐶', '🐱', '🦊', '🐻', '🐼', '🦁', '🐸', '🐧', '🦅', '🦉'
]

export function PlayersManagement() {
  const [players, setPlayers] = useState<Player[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingPlayer, setEditingPlayer] = useState<Player | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    avatar: '👤',
    handicap: 0
  })

  useEffect(() => {
    const saved = localStorage.getItem('golfDuel_players')
    if (saved) {
      setPlayers(JSON.parse(saved))
    }
  }, [])

  const saveToStorage = (newPlayers: Player[]) => {
    localStorage.setItem('golfDuel_players', JSON.stringify(newPlayers))
    setPlayers(newPlayers)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (editingPlayer) {
      const updated = players.map(p => 
        p.id === editingPlayer.id 
          ? { ...p, ...formData }
          : p
      )
      saveToStorage(updated)
    } else {
      const newPlayer: Player = {
        id: Date.now().toString(),
        ...formData,
        totalRounds: 0,
        bestScore: null
      }
      saveToStorage([...players, newPlayer])
    }
    
    setFormData({ name: '', avatar: '👤', handicap: 0 })
    setEditingPlayer(null)
    setIsDialogOpen(false)
  }

  const handleEdit = (player: Player) => {
    setEditingPlayer(player)
    setFormData({
      name: player.name,
      avatar: player.avatar,
      handicap: player.handicap
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    const updated = players.filter(p => p.id !== id)
    saveToStorage(updated)
  }

  const resetDialog = () => {
    setFormData({ name: '', avatar: '👤', handicap: 0 })
    setEditingPlayer(null)
    setIsDialogOpen(false)
  }

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1>Players Management</h1>
            <p className="text-muted-foreground">Add and manage players for your golf rounds</p>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => resetDialog()}>
                <Plus className="size-4 mr-2" />
                Add Player
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{editingPlayer ? 'Edit Player' : 'Add New Player'}</DialogTitle>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter player name"
                    required
                  />
                </div>
                
                <div>
                  <Label>Avatar</Label>
                  <div className="grid grid-cols-10 gap-2 mt-2">
                    {AVATAR_OPTIONS.map((avatar) => (
                      <button
                        key={avatar}
                        type="button"
                        className={`p-2 rounded-md border ${
                          formData.avatar === avatar ? 'border-primary bg-primary/10' : 'border-border'
                        }`}
                        onClick={() => setFormData(prev => ({ ...prev, avatar }))}
                      >
                        {avatar}
                      </button>
                    ))}
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="handicap">Handicap</Label>
                  <Input
                    id="handicap"
                    type="number"
                    value={formData.handicap}
                    onChange={(e) => setFormData(prev => ({ ...prev, handicap: parseInt(e.target.value) || 0 }))}
                    placeholder="0"
                  />
                </div>
                
                <div className="flex gap-2 pt-4">
                  <Button type="submit" className="flex-1">
                    {editingPlayer ? 'Update Player' : 'Add Player'}
                  </Button>
                  <Button type="button" variant="outline" onClick={resetDialog}>
                    Cancel
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {players.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <p className="text-muted-foreground mb-4">No players added yet</p>
              <Button onClick={() => setIsDialogOpen(true)}>
                <Plus className="size-4 mr-2" />
                Add Your First Player
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {players.map((player) => (
              <Card key={player.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback>{player.avatar}</AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-base">{player.name}</CardTitle>
                        <Badge variant="secondary">HC: {player.handicap}</Badge>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => handleEdit(player)}>
                        <Edit className="size-4" />
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => handleDelete(player.id)}>
                        <Trash2 className="size-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Total Rounds:</span>
                      <span>{player.totalRounds}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Best Score:</span>
                      <span>{player.bestScore || 'N/A'}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}